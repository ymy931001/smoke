//请求配置
//  export const requestIp = 'http://garden.longjing.terabits-wx.cn:4000'; //移动服务器
//export const requestIp = "http://122.152.249.37:4000"; //测试服务器
// export const requestIp = "http://127.0.0.1:4100";
export const requestIp = "http://47.99.192.178:9090";
// export const requestIp = "http://192.168.31.225:9090";



export const downUrl= requestIp//下载报告地址
